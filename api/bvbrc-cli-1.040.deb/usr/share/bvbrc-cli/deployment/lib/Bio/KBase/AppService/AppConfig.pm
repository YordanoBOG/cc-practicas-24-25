package Bio::KBase::AppService::AppConfig;

use constant        data_api_url   => 'https://p3.theseed.org/services/data_api';
use constant        binning_data_api_url   => 'https://p3.theseed.org/services/data_api';
use constant        db_host   => '';
use constant        db_user   => '';
use constant        db_pass   => '';
use constant        db_name   => '';
use constant        seedtk   => '/disks/patric-common/seedtk-2019-0405';
use constant	    github_issue_repo_owner => 'olsonanl';
use constant	    github_issue_repo_name => 'app_service';
use constant	    github_issue_token => '';
use constant	    reference_data_dir => '/tmp';
use constant	    binning_genome_annotation_clientgroup => '';
use constant	    mash_reference_sketch => '/vol/patric3/production/data/trees/listOfRepRefGenomeFnaFiles.txt.msh';
use constant	    binning_spades_threads => '';
use constant	    binning_spades_ram => '';

use constant	    kma_db => '';
use constant	    metagenome_dbs => '';

use constant	    sched_db_host => '';
use constant	    sched_db_port => '';
use constant	    sched_db_user => '';
use constant	    sched_db_pass => '';
use constant	    sched_db_name => '';

use constant	    sched_default_cluster => 'P3Slurm';

use constant	    redis_host => '';
use constant	    redis_port => '';
use constant	    redis_db => '';

use constant	    slurm_control_task_partition => 'watcher';

use constant	    bebop_binning_user => '';
use constant	    bebop_binning_key => '';

use constant	    app_directory => 'app_specs';
use constant	    app_service_url => 'https://p3.theseed.org/services/app_service';

use base 'Exporter';
our @EXPORT_OK = qw(data_api_url github_issue_repo_owner github_issue_repo_name github_issue_token
		    db_host db_user db_pass db_name 
		    seedtk reference_data_dir
		    bebop_binning_user bebop_binning_key
		    sched_db_host sched_db_port sched_db_user sched_db_pass sched_db_name
		    sched_default_cluster
		    slurm_control_task_partition
		    binning_spades_threads binning_spades_ram
		    binning_genome_annotation_clientgroup mash_reference_sketch
		    app_directory app_service_url
		    redis_host redis_port redis_db
		    kma_db metagenome_dbs
		    binning_data_api_url
		    );
our %EXPORT_TAGS = (all => [@EXPORT_OK]);
1;

