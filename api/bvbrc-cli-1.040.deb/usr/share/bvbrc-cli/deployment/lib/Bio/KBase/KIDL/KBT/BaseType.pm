package Bio::KBase::KIDL::KBT::BaseType;

use Moose;

