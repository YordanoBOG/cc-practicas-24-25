#BEGIN_HEADER
#END_HEADER


class Workspace:
    '''
    Module Name:
    Workspace

    Module Description:
    
    '''

    ######## WARNING FOR GEVENT USERS #######
    # Since asynchronous IO can lead to methods - even the same method -
    # interrupting each other, you must be *very* careful when using global
    # state. A method could easily clobber the state set by another while
    # the latter method is running.
    #########################################
    #BEGIN_CLASS_HEADER
    #END_CLASS_HEADER

    # config contains contents of config file in a hash or None if it couldn't
    # be found
    def __init__(self, config):
        #BEGIN_CONSTRUCTOR
        #END_CONSTRUCTOR
        pass

    def create(self, ctx, input):
        # ctx is the context object
        # return variables are: output
        #BEGIN create
        #END create

        # At some point might do deeper type checking...
        if not isinstance(output, list):
            raise ValueError('Method create return value ' +
                             'output is not type list as required.')
        # return the results
        return [output]

    def update_metadata(self, ctx, input):
        # ctx is the context object
        # return variables are: output
        #BEGIN update_metadata
        #END update_metadata

        # At some point might do deeper type checking...
        if not isinstance(output, list):
            raise ValueError('Method update_metadata return value ' +
                             'output is not type list as required.')
        # return the results
        return [output]

    def get(self, ctx, input):
        # ctx is the context object
        # return variables are: output
        #BEGIN get
        #END get

        # At some point might do deeper type checking...
        if not isinstance(output, list):
            raise ValueError('Method get return value ' +
                             'output is not type list as required.')
        # return the results
        return [output]

    def update_auto_meta(self, ctx, input):
        # ctx is the context object
        # return variables are: output
        #BEGIN update_auto_meta
        #END update_auto_meta

        # At some point might do deeper type checking...
        if not isinstance(output, list):
            raise ValueError('Method update_auto_meta return value ' +
                             'output is not type list as required.')
        # return the results
        return [output]

    def get_download_url(self, ctx, input):
        # ctx is the context object
        # return variables are: urls
        #BEGIN get_download_url
        #END get_download_url

        # At some point might do deeper type checking...
        if not isinstance(urls, list):
            raise ValueError('Method get_download_url return value ' +
                             'urls is not type list as required.')
        # return the results
        return [urls]

    def get_archive_url(self, ctx, input):
        # ctx is the context object
        # return variables are: url, file_count, total_size
        #BEGIN get_archive_url
        #END get_archive_url

        # At some point might do deeper type checking...
        if not isinstance(url, basestring):
            raise ValueError('Method get_archive_url return value ' +
                             'url is not type basestring as required.')
        if not isinstance(file_count, int):
            raise ValueError('Method get_archive_url return value ' +
                             'file_count is not type int as required.')
        if not isinstance(total_size, int):
            raise ValueError('Method get_archive_url return value ' +
                             'total_size is not type int as required.')
        # return the results
        return [url, file_count, total_size]

    def ls(self, ctx, input):
        # ctx is the context object
        # return variables are: output
        #BEGIN ls
        #END ls

        # At some point might do deeper type checking...
        if not isinstance(output, dict):
            raise ValueError('Method ls return value ' +
                             'output is not type dict as required.')
        # return the results
        return [output]

    def copy(self, ctx, input):
        # ctx is the context object
        # return variables are: output
        #BEGIN copy
        #END copy

        # At some point might do deeper type checking...
        if not isinstance(output, list):
            raise ValueError('Method copy return value ' +
                             'output is not type list as required.')
        # return the results
        return [output]

    def delete(self, ctx, input):
        # ctx is the context object
        # return variables are: output
        #BEGIN delete
        #END delete

        # At some point might do deeper type checking...
        if not isinstance(output, list):
            raise ValueError('Method delete return value ' +
                             'output is not type list as required.')
        # return the results
        return [output]

    def set_permissions(self, ctx, input):
        # ctx is the context object
        # return variables are: output
        #BEGIN set_permissions
        #END set_permissions

        # At some point might do deeper type checking...
        if not isinstance(output, list):
            raise ValueError('Method set_permissions return value ' +
                             'output is not type list as required.')
        # return the results
        return [output]

    def list_permissions(self, ctx, input):
        # ctx is the context object
        # return variables are: output
        #BEGIN list_permissions
        #END list_permissions

        # At some point might do deeper type checking...
        if not isinstance(output, dict):
            raise ValueError('Method list_permissions return value ' +
                             'output is not type dict as required.')
        # return the results
        return [output]
